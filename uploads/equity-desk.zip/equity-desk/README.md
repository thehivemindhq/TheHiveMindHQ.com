# India Equity Desk 2.0 — a private, self-hosted portfolio dashboard

Equity Desk is a dashboard you run on your own computer. It pulls delayed market
data for your NSE/BSE holdings, shows them across multiple brokers in one place,
and analyses them through the lens of a long-term, quality-compounder framework —
then hands you ready-to-use prompts for deeper analysis in Claude.

**Your data never leaves your machine.** No account, no cloud, no sign-up. You run
it locally; your holdings sit in plain spreadsheet files only you can see.

This download ships with **sample holdings so the dashboard is fully populated the
moment you open it** — replace them with your own when ready (see GETTING_STARTED.md).

---

## What it does

- **One view across brokers.** A CSV per broker (Groww, Kite, …). See each on its
  own, or a consolidated "All Portfolios" view that merges a stock held in two
  places into one line.
- **Live-ish prices & valuation.** ~15-min-delayed quotes, day change, trailing
  P/E, a 52-week range marker, analyst price target, consensus signal
  (Strong Buy → Strong Sell), and each stock's Beta — per holding.
- **Position figures.** Value, % of total, P&L and P&L % once you enter quantity
  and average cost.
- **Top-line summary.** Invested, Current Value, Day's P&L (with %), Overall P&L,
  and **Day's Alpha vs Nifty 50** (your day return minus the index's).
- **Exit discipline.** Tag each holding **Long Term** or **Short Term**; set base
  trigger levels in the **Thresholds tab**; each holding's calibrated bands are
  `base × min(max(Beta, 0.7), 1.6)`, and a **Flag** lights up when a holding's
  P&L % breaches its lower or upper trigger.
- **Allocation analysis.** Interactive donut charts for Sector, Industry and
  market-cap tier; click any slice to drill in. Cap-tier weights compared to their
  matching index (Nifty 50 / Midcap 150 / Smallcap 250).
- **Portfolio characteristics.** Value-weighted Beta, blended P/E, analyst-implied
  forecast.
- **Live ticker tape** of the broad and sectoral Nifty indices across the top.
- **Frozen header & first column** so the name and column titles stay put as you
  scroll the wide table. A **Source** link per row jumps to the Yahoo Finance page.
- **The Claude tab.** A prompt builder that pre-fills your live portfolio figures
  into ready-to-paste prompts for three workflows: deploying new capital, checking
  a thesis, and analysing allocation drift.

## What it is not

It is **not** a trading terminal, a robo-advisor, or investment advice. Prices are
delayed, so it's for monitoring a long-horizon portfolio, not intraday trading.
Analyst signals and valuations come from a free public source and can be stale or
missing for thinly-covered names. Every figure is for your own information.

---

## Folder layout

```
equity-desk/
├── app.py                 # the local engine (you don't edit this)
├── requirements.txt
├── thresholds.json        # your trigger bases (editable in the Thresholds tab)
├── GETTING_STARTED.md     # plain-English setup — start here
├── README.md
├── LICENSE
├── Holdings/              # YOUR PORTFOLIOS — one CSV per broker
│   ├── groww.csv          # (sample data — replace with your own)
│   └── kite.csv
├── Claude/
│   └── theses.json        # your conservative thesis notes (template provided)
└── static/
    └── index.html         # the dashboard itself
```

## Requirements

- A computer (Windows or Mac).
- Python 3.10 or newer (free; the guide tells you how).
- An internet connection (to fetch quotes).

See **GETTING_STARTED.md** for step-by-step setup. Informational/educational use
only — not investment advice.
