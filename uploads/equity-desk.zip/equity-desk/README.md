# Equity Desk — a private, self-hosted portfolio dashboard for Indian equities

Equity Desk is a dashboard you run on your own computer. It pulls delayed market
data for your NSE/BSE holdings, shows them across multiple brokers in one place,
and helps you analyse them through the lens of a long-term, quality-compounder
framework — then hands you ready-to-use prompts for deeper analysis in Claude.

**Your data never leaves your machine.** There is no account, no cloud, no
sign-up. You run it locally; your holdings sit in plain spreadsheet files that
only you can see.

---

## What it does

- **One view across brokers.** Keep a CSV per broker (e.g. Groww, Kite). See each
  one on its own, or a consolidated "All Portfolios" view that merges a stock held
  in two places into a single line.
- **Live-ish prices & valuation.** ~15-minute-delayed quotes, day change, trailing
  & forward P/E, a 52-week range marker, analyst price targets and consensus
  signal (Strong Buy → Strong Sell) — per holding.
- **Allocation analysis.** Interactive donut charts for Sector, Industry, and
  market-cap tier (Large / Mid / Small / ETF). Click any slice to drill into the
  holdings behind it.
- **Cap-tier vs benchmark.** Each tier's weight, P&L, and today's move against its
  matching index (Nifty 50 / Midcap 150 / Smallcap 250).
- **Portfolio characteristics.** Value-weighted beta, blended P/E, and an
  analyst-implied forecast.
- **Live sector ticker.** A continuously scrolling tape of the broad and sectoral
  Nifty indices across the top.
- **The Claude tab.** A thesis library for each holding (your own conservative
  notes on why you own it and what would break the case), plus a prompt builder
  that pre-fills your live portfolio figures into ready-to-paste prompts for
  three workflows: deploying new capital, checking a thesis, and analysing
  allocation drift.

## What it is not

It is **not** a trading terminal, a robo-advisor, or investment advice. Prices are
delayed, so it's for monitoring a long-horizon portfolio, not intraday trading.
Analyst signals and valuations come from a free public data source and can be
stale or missing for thinly-covered names. Every figure is for your own
information and decision-making.

---

## Folder layout

```
equity-desk/
├── app.py                 # the local engine (you don't edit this)
├── requirements.txt
├── GETTING_STARTED.md     # plain-English setup, start here
├── README.md
├── LICENSE
├── Holdings/              # YOUR PORTFOLIOS — one CSV per broker
│   ├── groww.csv          # (sample data — replace with your own)
│   └── kite.csv
├── Claude/
│   └── theses.json        # your conservative thesis notes (template provided)
└── static/
    └── index.html         # the dashboard itself
```

## Requirements

- A computer (Windows or Mac).
- Python 3.10 or newer (free; the guide tells you how to install it).
- An internet connection (to fetch quotes).

See **GETTING_STARTED.md** for step-by-step setup. Informational/educational use
only — not investment advice.
