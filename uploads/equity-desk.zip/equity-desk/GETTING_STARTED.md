# Getting Started — from download to productive in ~15 minutes

No coding needed. You'll copy a couple of lines and press Enter. The dashboard
comes pre-loaded with sample holdings, so you'll see it working immediately —
then you swap in your own.

---

## Step 1 — Install Python (one time, ~3 min)

Python is the small engine that runs the dashboard.

**Windows**
1. Go to **python.org/downloads** and click the yellow **Download Python** button.
2. Open the downloaded file.
3. **Important:** on the first screen, tick **"Add python.exe to PATH"** at the
   bottom *before* clicking anything else.
4. Click **Install Now**, let it finish, then **Close**.

**Mac**
1. Go to **python.org/downloads**, download the macOS installer.
2. Open it and click through (defaults are fine).

---

## Step 2 — Unzip the download (~1 min)

Find `equity-desk.zip`, right-click → **Extract All** (Windows) or double-click
(Mac). You'll get a folder called `equity-desk` — put it somewhere easy like your
Desktop.

---

## Step 3 — Open a command window in that folder (~1 min)

**Windows:** open the `equity-desk` folder so you can see `app.py`. Click the
**address bar** at the top, type `cmd`, press **Enter**. A black window opens,
already pointing at the folder.

**Mac:** open **Terminal** (Cmd+Space, type "Terminal"), type `cd ` (with a space),
drag the `equity-desk` folder into the window, press **Enter**.

---

## Step 4 — Install the pieces it needs (one time, ~2 min)

Type this and press **Enter** (`pip3` on Mac if `pip` doesn't work):

```
pip install -r requirements.txt
```

Wait for the blinking cursor to return.

---

## Step 5 — Start the dashboard

```
python app.py
```

(`python3 app.py` on Mac.) You'll see: **India Equity Desk 2.0 running at
http://127.0.0.1:5000**

---

## Step 6 — Open it

In any browser, go to:

```
http://127.0.0.1:5000
```

It loads with the sample portfolio fully populated — values, P&L, charts,
thresholds and flags. **Keep the black window open** while you use it; closing it
switches the dashboard off.

---

## Step 7 — Make it yours (the productive part)

1. Open the `Holdings` folder — `groww.csv` and `kite.csv`, one file per broker.
2. Double-click one to open it in Excel. Each row is one holding, with these
   columns:
   - **symbol** — the Yahoo ticker. NSE stocks end in `.NS` (e.g. `TCS.NS`); BSE
     in `.BO`.
   - **name** — any label you like.
   - **sector** and **industry** — your own buckets (these drive the pie charts).
   - **horizon** — `Long Term` or `Short Term` (drives which threshold band
     applies; blank defaults to Long Term).
   - **qty** and **avg** — units held and your average buy price. Fill both to
     unlock value, P&L, weights and flags. Leave blank to just watch the price.
   - **cap** — `large`, `mid`, `small`, or `etf` (leave blank to auto-estimate;
     tag `etf` for funds).
3. Replace the sample rows with your own. Add/delete rows freely, rename files
   (e.g. `zerodha.csv`) or add more — each CSV becomes its own portfolio.
4. **Save** (keep the CSV format when Excel asks).
5. Back in the dashboard, click **↻ refresh now**. Your holdings appear — no
   restart needed.

### Set your exit triggers
Open the **Thresholds** tab and set the base lower/upper trigger for Long Term and
Short Term (defaults: LT −25% / +20%, ST −18% / +35%). Save. Each holding's own
band is then `base × min(max(Beta, 0.7), 1.6)`, and the **Flag** column lights up
when a holding's P&L % crosses its band.

---

## Next time you want it

Repeat only **Step 3** (open the command window) and **Step 5** (`python app.py`).
Steps 1, 2 and 4 are one-time.

## If something goes wrong

- **"python is not recognized" (Windows):** the PATH box in Step 1 was missed.
  Reinstall and tick it — or type `py app.py`.
- **"could not reach backend":** the black window closed. Reopen it (Steps 3 + 5).
- **A stock shows "data unavailable":** check the ticker spelling and the `.NS` /
  `.BO` ending (use the row's **Source** link to verify on Yahoo), or the data
  source is briefly rate-limiting — wait a minute and refresh.

Informational/educational use only — not investment advice.
