"""
India Equity Dashboard - backend
---------------------------------
~15-min-delayed Yahoo quotes + analyst targets + market cap + beta + P/E,
served to a multi-portfolio dashboard. No broker account or API key required.

PORTFOLIOS: each .csv in Holdings/ is one broker (groww.csv -> "GROWW").
CSV columns: symbol, name, sector, qty, avg, cap
  - qty/avg : optional; fill both for value, P&L, weight (cost/invested is
              computed from qty+avg even when a live price can't be fetched)
  - cap     : optional; large | mid | small | etf. If blank it's approximated
              from market cap (rough thresholds, see classify()). Tag ETFs
              explicitly with "etf" so they group into their own tier.
"""

from datetime import datetime, timezone, timedelta
import csv
import json
import os
import threading
import time

from flask import Flask, jsonify, request, send_from_directory
import yfinance as yf

app = Flask(__name__, static_folder="static")
HERE = os.path.dirname(os.path.abspath(__file__))
HOLDINGS_DIR = os.path.join(HERE, "Holdings")
THESES_PATH = os.path.join(HERE, "Claude", "theses.json")
THRESHOLDS_PATH = os.path.join(HERE, "thresholds.json")

# Exit/review trigger bases (in %). Per-stock thresholds = base x clamp(beta,0.7,1.6).
DEFAULT_THRESHOLDS = {"longLower": -25.0, "longUpper": 20.0,
                      "shortLower": -18.0, "shortUpper": 35.0}

DEFAULT_WATCHLIST = [
    {"symbol": "CAMS.NS",       "name": "CAMS",          "sector": "Financials",    "qty": None, "avg": None, "cap": None},
    {"symbol": "BAJFINANCE.NS", "name": "Bajaj Finance", "sector": "Financials",    "qty": None, "avg": None, "cap": None},
    {"symbol": "SIEMENS.NS",    "name": "Siemens",       "sector": "Capital Goods", "qty": None, "avg": None, "cap": None},
]

BENCHMARKS = [
    {"symbol": "^NSEI",             "name": "NIFTY 50",         "tier": "large"},
    {"symbol": "^CRSLDX",           "name": "NIFTY 500",        "tier": "market"},
    {"symbol": "NIFTYMIDCAP150.NS", "name": "NIFTY MIDCAP 150", "tier": "mid"},
    {"symbol": "NIFTYSMLCAP250.NS", "name": "NIFTY SMLCAP 250", "tier": "small"},
]

# NSE sector / thematic indices for the scrolling ticker tape (verified Yahoo symbols).
SECTOR_INDICES = [
    {"symbol": "^NSEBANK",   "name": "NIFTY BANK"},
    {"symbol": "^CNXIT",     "name": "NIFTY IT"},
    {"symbol": "^CNXAUTO",   "name": "NIFTY AUTO"},
    {"symbol": "^CNXPHARMA", "name": "NIFTY PHARMA"},
    {"symbol": "^CNXFMCG",   "name": "NIFTY FMCG"},
    {"symbol": "^CNXMETAL",  "name": "NIFTY METAL"},
    {"symbol": "^CNXENERGY", "name": "NIFTY ENERGY"},
    {"symbol": "^CNXFIN",    "name": "NIFTY FIN SERVICES"},
    {"symbol": "^CNXREALTY", "name": "NIFTY REALTY"},
    {"symbol": "^CNXMEDIA",  "name": "NIFTY MEDIA"},
    {"symbol": "^CNXPSUBANK","name": "NIFTY PSU BANK"},
    {"symbol": "^CNXINFRA",  "name": "NIFTY INFRA"},
]

LARGE_FLOOR = 9.0e11   # ~ Rs 90,000 cr  (APPROXIMATE — set cap in CSV to be exact)
MID_FLOOR = 3.0e11     # ~ Rs 30,000 cr

CACHE_TTL = 60
INFO_TTL = 12 * 3600
IST = timezone(timedelta(hours=5, minutes=30))

_cache = {"data": None, "ts": 0.0}
_lock = threading.Lock()
_info_cache = {}            # symbol -> {target, mcap, beta, pe, ts}
_info_lock = threading.Lock()
_info_running = {"flag": False}


def _num(v):
    v = (v or "").strip()
    try:
        return float(v) if v else None
    except ValueError:
        return None


def _norm_horizon(v):
    """Normalise the CSV horizon tag. Blank defaults to Long Term."""
    v = (v or "").strip().lower()
    if v in ("short term", "short", "st"):
        return "Short Term"
    return "Long Term"


def load_thresholds():
    if os.path.exists(THRESHOLDS_PATH):
        try:
            with open(THRESHOLDS_PATH, encoding="utf-8") as f:
                d = json.load(f)
            return {k: float(d.get(k, DEFAULT_THRESHOLDS[k])) for k in DEFAULT_THRESHOLDS}
        except Exception as exc:  # noqa: BLE001
            print(f"[warn] thresholds.json: {exc}")
    return dict(DEFAULT_THRESHOLDS)


_thresholds = load_thresholds()


def load_portfolios():
    rows, names = [], []
    if os.path.isdir(HOLDINGS_DIR):
        files = sorted(f for f in os.listdir(HOLDINGS_DIR) if f.lower().endswith(".csv"))
        for fn in files:
            pname = os.path.splitext(fn)[0].upper()
            names.append(pname)
            with open(os.path.join(HOLDINGS_DIR, fn), newline="", encoding="utf-8-sig") as f:
                for r in csv.DictReader(f):
                    sym = (r.get("symbol") or "").strip()
                    if not sym:
                        continue
                    cap = (r.get("cap") or "").strip().lower() or None
                    rows.append({
                        "portfolio": pname,
                        "symbol": sym,
                        "name": (r.get("name") or sym).strip(),
                        "sector": (r.get("sector") or "Uncategorised").strip(),
                        "industry": (r.get("industry") or "").strip() or None,
                        "horizon": _norm_horizon(r.get("horizon")),
                        "qty": _num(r.get("qty")),
                        "avg": _num(r.get("avg")),
                        "cap": cap if cap in ("large", "mid", "small", "etf") else None,
                    })
    if not rows:
        rows = [{**w, "portfolio": "PORTFOLIO"} for w in DEFAULT_WATCHLIST]
        names = ["PORTFOLIO"]
    return rows, names


def _signal_label(mean):
    """Map Yahoo's 1-5 recommendationMean to a label (1=Strong Buy .. 5=Sell)."""
    if mean is None:
        return None
    if mean <= 1.5:
        return "Strong Buy"
    if mean <= 2.5:
        return "Buy"
    if mean <= 3.5:
        return "Hold"
    if mean <= 4.5:
        return "Sell"
    return "Strong Sell"


def load_theses():
    """Load the conservative thesis library (symbol -> {thesis, conservative, ...})."""
    if not os.path.exists(THESES_PATH):
        return {}
    try:
        with open(THESES_PATH, encoding="utf-8") as f:
            data = json.load(f)
        return {k: v for k, v in data.items() if not k.startswith("_")}
    except Exception as exc:  # noqa: BLE001
        print(f"[warn] could not load theses.json: {exc}")
        return {}


def classify(cap_override, mcap):
    if cap_override:                 # large | mid | small | etf
        return cap_override
    if not mcap:
        return None
    if mcap >= LARGE_FLOOR:
        return "large"
    if mcap >= MID_FLOOR:
        return "mid"
    return "small"


def _quote(symbol):
    try:
        fi = yf.Ticker(symbol).fast_info
        last = float(fi["lastPrice"])
        prev = float(fi["previousClose"])
        change = last - prev
        pct = (change / prev * 100) if prev else 0.0
        out = {"price": round(last, 2), "prevClose": round(prev, 2),
               "change": round(change, 2), "changePct": round(pct, 2)}
        try:
            hi = float(fi["yearHigh"]); lo = float(fi["yearLow"])
            if hi:
                out["wk52High"] = round(hi, 2)
                out["pctFromHigh"] = round((last - hi) / hi * 100, 2)  # <=0, distance below high
            if lo:
                out["wk52Low"] = round(lo, 2)
                out["pctFromLow"] = round((last - lo) / lo * 100, 2)   # >=0, distance above low
        except Exception:  # noqa: BLE001 — 52w range is optional
            pass
        return out
    except Exception as exc:  # noqa: BLE001
        print(f"[warn] could not fetch {symbol}: {exc}")
        return None


def _fetch_info(symbols):
    for s in symbols:
        target = mcap = beta = pe = None
        fpe = None
        recMean = recKey = nAnalysts = None
        yindustry = None
        try:
            info = yf.Ticker(s).get_info()
            t = info.get("targetMeanPrice"); target = float(t) if t else None
            m = info.get("marketCap"); mcap = float(m) if m else None
            b = info.get("beta"); beta = float(b) if b is not None else None
            p = info.get("trailingPE"); pe = float(p) if p else None
            fp = info.get("forwardPE"); fpe = float(fp) if fp else None
            rm = info.get("recommendationMean"); recMean = float(rm) if rm else None
            recKey = info.get("recommendationKey") or None
            na = info.get("numberOfAnalystOpinions"); nAnalysts = int(na) if na else None
            yindustry = info.get("industry") or None
        except Exception as exc:  # noqa: BLE001
            print(f"[warn] info {s}: {exc}")
        with _info_lock:
            _info_cache[s] = {"target": target, "mcap": mcap, "beta": beta, "pe": pe,
                              "fpe": fpe, "recMean": recMean, "recKey": recKey,
                              "nAnalysts": nAnalysts, "industry": yindustry, "ts": time.time()}
    with _info_lock:
        _info_running["flag"] = False


def get_info_async(symbols):
    now = time.time()
    stale = []
    with _info_lock:
        for s in symbols:
            c = _info_cache.get(s)
            if not c or (now - c["ts"]) > INFO_TTL:
                stale.append(s)
        if stale and not _info_running["flag"]:
            _info_running["flag"] = True
            threading.Thread(target=_fetch_info, args=(stale,), daemon=True).start()


def _market_open():
    now = datetime.now(IST)
    if now.weekday() >= 5:
        return False
    t = now.time()
    return t >= datetime.strptime("09:15", "%H:%M").time() and \
        t <= datetime.strptime("15:30", "%H:%M").time()


def _build():
    watchlist, portfolios = load_portfolios()
    get_info_async(list({w["symbol"] for w in watchlist}))

    holdings = []
    for w in watchlist:
        q = _quote(w["symbol"])
        row = {**w, **(q or {}), "ok": q is not None}
        # Cost basis is CSV-only, so compute it even if the price didn't fetch.
        if w.get("qty") and w.get("avg"):
            invested = w["avg"] * w["qty"]
            row["invested"] = round(invested, 2)
            if q:
                value = q["price"] * w["qty"]
                row["value"] = round(value, 2)
                row["pnl"] = round(value - invested, 2)
                row["pnlPct"] = round((value - invested) / invested * 100, 2) if invested else 0.0
                row["dayPnl"] = round(q["change"] * w["qty"], 2)
        with _info_lock:
            ic = _info_cache.get(w["symbol"])
        mcap = ic.get("mcap") if ic else None
        if ic:
            if q and ic.get("target"):
                row["target"] = round(ic["target"], 2)
                row["upsidePct"] = round((ic["target"] - q["price"]) / q["price"] * 100, 2)
            if mcap:
                row["marketCap"] = mcap
            if ic.get("beta") is not None:
                row["beta"] = round(ic["beta"], 2)
            if ic.get("pe"):
                row["pe"] = round(ic["pe"], 2)
            if ic.get("fpe"):
                row["fpe"] = round(ic["fpe"], 2)
            if ic.get("recMean"):
                row["recMean"] = round(ic["recMean"], 2)
                row["signal"] = _signal_label(ic["recMean"])
            elif ic.get("recKey"):
                row["signal"] = ic["recKey"].replace("_", " ").title()
            if ic.get("nAnalysts"):
                row["nAnalysts"] = ic["nAnalysts"]
            if not row.get("industry") and ic.get("industry"):
                row["industry"] = ic["industry"]
        row["capTier"] = classify(w.get("cap"), mcap)
        if not row.get("horizon"):
            row["horizon"] = "Long Term"
        if not row.get("industry"):
            row["industry"] = "Unclassified"
        holdings.append(row)

    benchmarks = []
    for b in BENCHMARKS:
        q = _quote(b["symbol"])
        benchmarks.append({**b, **(q or {}), "ok": q is not None})

    # ticker tape = the four benchmarks followed by all sector indices
    tickers = [{"name": b["name"], "price": b.get("price"),
                "changePct": b.get("changePct"), "ok": b["ok"]} for b in benchmarks]
    for si in SECTOR_INDICES:
        q = _quote(si["symbol"])
        tickers.append({"name": si["name"],
                        "price": q["price"] if q else None,
                        "changePct": q["changePct"] if q else None,
                        "ok": q is not None})

    return {
        "asOf": datetime.now(IST).strftime("%d %b %Y, %H:%M:%S IST"),
        "marketOpen": _market_open(),
        "benchmarks": benchmarks,
        "tickers": tickers,
        "portfolios": portfolios,
        "theses": load_theses(),
        "thresholds": dict(_thresholds),
        "holdings": holdings,
    }


def _get_data():
    with _lock:
        if _cache["data"] is None or (time.time() - _cache["ts"]) > CACHE_TTL:
            _cache["data"] = _build()
            _cache["ts"] = time.time()
        return _cache["data"]


@app.route("/api/data")
def api_data():
    return jsonify(_get_data())


@app.route("/api/thresholds", methods=["POST"])
def api_thresholds():
    """Save the four trigger bases (long/short x lower/upper) to thresholds.json."""
    data = request.get_json(force=True, silent=True) or {}
    out = {}
    for k in DEFAULT_THRESHOLDS:
        try:
            out[k] = float(data[k])
        except (KeyError, TypeError, ValueError):
            return jsonify({"ok": False, "error": f"missing or invalid value for {k}"}), 400
    global _thresholds
    _thresholds = out
    try:
        with open(THRESHOLDS_PATH, "w", encoding="utf-8") as f:
            json.dump(out, f, indent=2)
    except Exception as exc:  # noqa: BLE001
        return jsonify({"ok": False, "error": str(exc)}), 500
    _cache["data"] = None  # force payload rebuild so new thresholds propagate
    return jsonify({"ok": True, "thresholds": out})


@app.route("/")
def index():
    return send_from_directory("static", "index.html")


if __name__ == "__main__":
    print("India Equity Desk 2.0 running at  http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, debug=False)
